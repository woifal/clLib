"use strict";

clLib.localStorage.indexes = {
	routes: {
		/*"French" : {
			"distinct": ["Colour", "Sector"]
		}*//*,
		"Area": {
			"distinct": ["Colour", "Sector"]
		},
		"Sector" : {
			"distinct": ["Colour", "French"]
		}*/
		/*,
		"UIAA",
		"French"
		,
		"Bleau",
		"USA"*/
	}
	/*,
	routeLogs: [
	]*/
};
